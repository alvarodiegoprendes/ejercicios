Static HTML files for documentation go here.
